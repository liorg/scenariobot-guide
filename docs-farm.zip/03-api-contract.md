# API Contract

Base URL: `VITE_API_URL`, defaulting to `https://vid.michal-solutions.com/api`.
Every endpoint below is authenticated with a Supabase JWT in
`Authorization: Bearer <token>`, added automatically by `apiFetch`.

This document is derived from the frontend client modules — it describes what
the UI *calls*, which is the contract the backend must satisfy. Response
shapes marked **[verify]** were inferred from how the UI consumes them.

## Auth and settings

Login, signup, password reset and logout go **directly to Supabase Auth**, not
to the backend (`src/api/auth.js`). OAuth is Supabase too — **Google and
GitHub**, both via `signInWithOAuth`; GitHub requests the `read:user
user:email` scopes so a hidden profile email still arrives, which matters
because the `users` row is keyed on it. The backend owns the profile:

| Method | Path | Notes |
|---|---|---|
| GET | `/auth/settings` | |
| PUT | `/auth/settings` | body = settings object |
| POST | `/auth/avatar` | `multipart/form-data`, field `file` |
| POST | `/settings/2fa/request` | no body — sends a WhatsApp code |
| POST | `/settings/2fa/verify` | `{ "code": "123456" }` |
| GET | `/settings/2fa/status` | `verified`, `verified_at`, `mobile_set`, `ttl_sec`, `resend_sec` |
| GET | `/phones/can_add` | the add-phone gate, read-only |

The backend **also** offers the full set — `/auth/login`, `/auth/signup`,
`/auth/google`, `/auth/forgot-password`, `/auth/me`, `/auth/health` — for
service clients and scripts. The UI does not call them.

### The token rule

`auth.py` **does not mint its own JWT**. Every token it returns is a real
Supabase access token, which is exactly what `dependencies._verify_user_token`
expects.

This is worth stating because it was not always true, and the file records why
it changed:

> The previous `make_jwt()` produced an HS256 token with `sub=<email>` and no
> `aud` claim, so it was rejected by every other router (401) — and when it was
> accepted, `uid` resolved to the email address.

So a token from `POST /auth/login` and a token from supabase-js in the browser
are interchangeable everywhere. If `GET /auth/me` ever returns an email in
`uid`, something is minting tokens again.

### What `PUT /auth/settings` will not accept

The Settings screen now sends six fields:

```json
{ "full_name": "…", "mobile": "…", "lang": "he",
  "trusted_domain": "example.com", "notify_email": true,
  "notify_errors_only": true }
```

> **Check the model when adding a field here.** The patch is built from the
> Pydantic model, not from the raw body, so a field the model does not declare
> is dropped **silently** — the request returns 200 and nothing is written. A
> new settings field therefore needs the column *and* the model field; the
> column alone looks like it works.

`trusted_domain` is not stored as typed — it is **verified** (DNS resolves to
public addresses only, then a real TLS handshake, then a certificate with more
than `TRUSTED_CERT_MIN_DAYS` left) before anything is written, and the whole
settings save fails with 422 if it does not pass:

```json
{ "error": "trusted_domain_invalid",
  "items": [ { "url": "https://…", "error": "certificate expires too soon (2026-11-01)" } ] }
```

The same list is what gates `fetch` in scenario code, checked at scenario-save
time with `ensure_script_urls` → 422 `script_url_not_trusted`. Both are in
[12-trusted-domains.md](12-trusted-domains.md).

Two fields are left out on purpose, and stay out:

| Field | Why |
|---|---|
| `package_type` | a billing field — accepting it let any caller upgrade their own plan with a PUT |
| `avatar` | writable only through `POST /auth/avatar`, so the stored URL is always one this backend uploaded |

The same pattern guards `PATCH /phones/{id}`, which accepts `label`, `color`
and `lang` only: *"a raw dict would let a caller set `user_id` or
`creds_base64` directly."*

### Columns, not `select("*")`

Both `auth.py` and `phones.py` define an explicit column list and warn against
replacing it:

- `USER_COLUMNS` — the users table also carries provider ids and internal
  billing flags.
- `PHONE_COLUMNS` — `creds_base64` holds the Baileys session and **must never
  leave the backend**.

An innocuous-looking `select("*")` in either file is a credential leak.

### Two-factor verification

`routers/two_factor.py`. The full pipeline is in
[11-otp-2fa.md](11-otp-2fa.md); the contract is:

| | `POST /settings/2fa/request` |
|---|---|
| **200** | `{ ok, status: "sent", sent_to, expires_in, resend_in }` |
| **202** | the same body with `status: "queued"` — written, not yet sent |
| **400 / 409 / 410 / 429 / 502** | `detail` is a ready-to-show sentence |

`sent_to` is masked (`+972 •••• 2491`), so the response can be displayed
without echoing the number back.

**202 is not an error.** The request waits up to 8 seconds for the sender to
pick the row up and only then gives up waiting; the code usually still
arrives. Only **502** means it will not.

`POST /settings/2fa/verify` takes `{"code": "\\d{6}"}` — the pattern is on the
Pydantic field, so a malformed code is a 422 before any RPC runs, and a
malformed code never counts against the five attempts.

### The gates

| Dependency | Raises |
|---|---|
| `require_2fa` | 403 `TWO_FACTOR_REQUIRED` |
| `require_phone_admin` | 403 beta message, **then** 403 `TWO_FACTOR_REQUIRED` |

`TWO_FACTOR_REQUIRED` is a literal the frontend matches on, so it is a code in
`detail`, not a sentence. The beta message is the opposite — a sentence meant
to be shown as-is.

`GET /phones/can_add` is the read-only form, and `reason` is the one field to
switch on: `null`, `"beta"` or `"2fa"`.

> **The two phone gates disagree.** `POST /phones/provision` admits a caller who
> is **either** on the allowlist **or** 2FA-verified:
> ```python
> if not (is_phone_admin(user) or is_2fa_verified(db, user["uid"])):
> ```
> while `phone_admin.require_phone_admin` still demands **both**, and
> `GET /phones/can_add` reports `can_add = admin and verified`. So a verified
> non-admin can provision a phone, but the button that starts it is greyed out
> and any route guarded by `require_phone_admin` refuses them. Whichever rule is
> intended, the three need to say the same thing — `can_add` is what the UI
> believes.

**Where each gate sits:**

| Operation | Enforced in | Unverified result |
|---|---|---|
| `POST /phones/provision` (new phone) | the router — allowlist **OR** 2FA | 403 |
| `POST /phones/provision` (reconnect) | **ungated**, by design | works |
| starting a scenario call | `spine_ensure_call` | `TWO_FACTOR_REQUIRED` |
| the API console | the frontend only — the button is hidden and `/api` redirects | no button |

The API console has no server-side gate of its own because it is a client for
endpoints that each enforce their own; hiding it is about not handing an
unverified account a request builder.

### The 2FA mobile is never a bot phone

Both directions are refused, in SQL rather than in Python:

| Attempt | Enforced by | Response |
|---|---|---|
| verify a number that is already a bot phone | `rpc_otp_request` | 409 `MOBILE_IS_BOT_PHONE` |
| save a bot phone's number as the mobile | `users_mobile_reset_2fa` trigger | P0001 `MOBILE_IS_BOT_PHONE` |
| provision the verified mobile as a bot phone | `rpc_is_2fa_mobile` from `phones.py` | 409 `TWO_FA_PHONE_CONFLICT` |

`phones.py` calls the RPC rather than normalising in Python:

> Normalization and comparison happen in the DB (`rpc_is_2fa_mobile` →
> `norm_mobile`), the same rule as `rpc_otp_request` and the users trigger.

Keeping the rule in one place is the point — a Python copy of `norm_mobile` is
a fourth implementation that can drift from the other three, and a drift here
is a bypass, not a cosmetic bug. See [11-otp-2fa.md](11-otp-2fa.md).

> **Route order.** `/phones/can_add` must be registered before
> `/phones/{phone_id}`, or the id route captures `can_add` as a phone id.

## Phones

### Three fields that are not stored on the row

`GET /phones/` returns `status_event`, `rented` and `rent_end_time` alongside
the stored columns.

**`status_event`** is `waiting` while an async action is in flight —
disconnect, today — and `complete` otherwise. `POST /{id}/logout` sets it
*before* calling the agent, so the card greys out immediately; a DB trigger
closes it when `status` actually changes. Both failure paths set it back.

It also expires:

```python
# waiting older than STATUS_EVENT_TTL_SEC shows as complete (the status never
# changed — e.g. a phone that was already disconnected)
```

Read-time only, defaulting to 180 s. The flag in the database stays as it is and
is closed by the next action. Without it, disconnecting an already-disconnected
phone leaves the card grey forever, because the trigger waits for a change that
never comes.

**`rented` / `rent_end_time`** are joined in per request from the `rent` table,
for `sim_id` phones with an active rental of the caller's. They drive the SMS
tab and the countdown.

### A rented phone cannot be deleted

```python
if sim.data and sim.data[0].get("sim_id"):
    raise HTTPException(409, "Rented phone — end the rental instead of deleting it")
```

Checked before the delete, so a `DELETE /phones/{id}` on a rented phone is a
409 rather than a handset vanishing from the rack.


| Method | Path | Notes |
|---|---|---|
| GET | `/phones/` | trailing slash is required |
| GET | `/phones/{phone_id}` | |
| POST | `/phones/provision` | QR or pairing-code provisioning |
| GET | `/phones/{phone_id}/qrcode` | polled while pairing |
| POST | `/phones/{phone_id}/pairing-code/refresh` | |
| POST | `/phones/{phone_id}/pause` | |
| POST | `/phones/{phone_id}/resume` | |
| POST | `/phones/{phone_id}/logout` | |
| POST | `/phones/{phone_id}/send/text` | `{ jid, text }` |
| PATCH | `/phones/{phone_id}` | |
| DELETE | `/phones/{phone_id}` | |

The UI backend serves these by calling HostAgent directly through the
`phones.py` helpers — never through Spine.

## Contacts

### There is no delete

`DELETE /contacts/{contact_id}` is a **soft delete** — it sets `tag = "inactive"`
and returns `{ ok, tag, last_tag_change }`. Messages, `ping_sender` rows and
draft links are all kept:

```python
# אין מחיקה פיזית — ההודעות וההיסטוריה נשמרות
```

A contact's state is its `tag`, and `last_tag_change` is maintained by a **DB
trigger** rather than by the router, so it is right whoever wrote the row:

| `tag` | Meaning | In the UI |
|---|---|---|
| `new` | created by a PING, awaiting a reply | "not identified" |
| `draft` | the container opened it from an inbound message | "not identified" |
| `active` | handshake finished, LID linked | Active |
| `inactive` | set aside | Inactive section, ⏸ |
| `ignore` | hidden | **nowhere** |

`PATCH /contacts/{id}` is what sets `inactive` and `ignore` — the UI uses it for
both buttons rather than the DELETE.

**A PING revives any of them.** `create-from-ping` upgrades `draft`, `inactive`
*and* `ignore` back to `new`:

```python
if contact.get("tag") in ("draft", "inactive", "ignore"):
```

So "ignore" is not a block — it hides a contact from the list, and the next
deliberate PING brings it back. Worth knowing before treating it as a block
list.

`GET /contacts` and `GET /contacts/{id}` both return `tag`, `lang` and
`last_tag_change` in their column list.

| Method | Path | Notes |
|---|---|---|
| GET | `/contacts?phone_id=` | list for a phone |
| GET | `/contacts/{contact_id}` | fresh row from the DB, used when opening the edit form |
| POST | `/phones/{phone_id}/contacts` | create |
| PATCH | `/contacts/{contact_id}` | update |
| DELETE | `/contacts/{contact_id}` | |
| GET | `/contacts/check-phone?phone_id=&number=` | digits only |
| GET | `/contacts/{contact_id}/messages` | |
| GET | `/phones/{phone_id}/contacts/{contact_id}/chat` | |
| POST | `/contacts/create-from-ping` | `{ phone_id, target_number, name, override_contact_id, lang }` — `lang: null` means "use the user's language" |
| GET | `/contacts/outgoing-with-replies/{phone_id}` | |
| POST | `/contacts/select-response` | `{ contact_id, message_id, parent_contact_id }` |

A contact carries a `tag`. `CallsScreen` treats `tag === "active"` as
"chattable", which is a separate concept from a call being active.

## Messages

| Method | Path | Notes |
|---|---|---|
| GET | `/messages/phone/{phone_id}/contact/{contact_id}/page?limit=&before_sent_at=&before_id=` | keyset paging, newest page when `before_*` is omitted |
| GET | `…/page?limit=&after_sent_at=` | polling for new messages only |
| GET | `/messages/phone/{phone_id}/contact/{contact_id}?limit=` | unpaged |
| GET | `/messages/contact/{contact_id}?limit=&phone_number=` | legacy fallback when `phone.id` is unknown |
| GET | `/messages/phone/{phone_id}/last` | last message per contact, for the sidebar preview |

Page response: `{ messages, next_cursor, has_more }` where `next_cursor` is
`{ sent_at, id }`.

## Scenarios

| Method | Path | Notes |
|---|---|---|
| GET | `/phones/{phone_id}/scenarios/?page=` | trailing slash required |
| GET | `/phones/{phone_id}/scenarios/{scenario_id}` | |
| POST | `/phones/{phone_id}/scenarios/` | |
| PUT | `/phones/{phone_id}/scenarios/{scenario_id}` | |
| DELETE | `/phones/{phone_id}/scenarios/{scenario_id}` | |
| POST | `/phones/{phone_id}/scenarios/{scenario_id}/publish` | no body |
| GET | `/phones/{phone_id}/scenarios/by-type/{event_type}` | |
| POST | `/scenarios/compile-check` | `{ code, card_type, timeout_ms, payload }` — runs one Deno card against the test Worker |
| POST | `/scenarios/compile` | `{ scenario_json }` — full ICR compile |

### Scenario import / export — `routers/scenario_io.py`

| Method | Path | Does |
|---|---|---|
| POST | `…/scenarios/io/export-metadata` | canvas → the template definitions to embed in the file |
| POST | `…/scenarios/io/preview` | file → name conflict + a decision per template, **no writes** |
| POST | `…/scenarios/io/commit` | `mode: "override" \| "new"` |

**`metadata.templates` exists only in the file.** It is never stored and never
reaches the Worker:

```python
cfg.pop("metadata", None)   # לעולם לא ב-DB
```

`commit` turns it into decisions, rewrites `templateId` / `templateName` /
`templateLang` in the canvas, and throws it away. Field names in the canvas do
not change, so `IcrConverter` and the ScenarioEngine are unaffected — which is
what makes this feature additive.

#### How a template is matched

`_resolve` decides per `templateId`, and the order is the design:

| `action` | Means |
|---|---|
| `matched_id` | that id already exists on this phone |
| `matched_signature` | same content + same language, under any name |
| `create` | will be created with a new id and published |
| `invalid` | in the metadata but fails `_validate` — skipped |
| `missing` | neither on the phone nor in the file (a pre-metadata export) |

The signature is a SHA-256 of the **normalised** content, truncated to 16 hex —
id and name deliberately excluded:

```python
raw = json.dumps(_norm_content(content), sort_keys=True, ensure_ascii=False)
```

So an identical template under a different name is reused rather than
duplicated. Among several matches the sort prefers the **same name, then
published, then approved** — the most useful candidate rather than the first.

A created template gets a free name from `_free_template_name` (`welcome_2`),
because WhatsApp requires name+language to be unique per WABA.

#### Publish failure does not fail the import

```python
async def _try_publish(...):   # כשל לא מפיל את היבוא — התבנית נשארת טיוטה
```

The decision comes back with `publishError`, and the scenario is still written.
That is the right call: a provider rejection is not a reason to lose the import.

#### Other rules worth knowing

- **`commit` recomputes the decisions** rather than trusting the preview's —
  `# לא סומכים על ה-preview`. The preview is advisory; nothing the client sends
  back decides what happens.
- **Override writes `status: "draft"`**, so overriding a live scenario
  unpublishes it.
- **The target name wins on override**, not the file's `fileName`; for `new`,
  the designer's name is used and `fileName` is only a fallback.
- **`botContact` from another phone is dropped** — `_valid_contact` checks the
  contact belongs to this phone, because a foreign `contact_id` is a broken FK.

## Schedules

| Method | Path | Notes |
|---|---|---|
| GET | `/schedules?phone_id=&status=` | flat array, legacy |
| GET | `/schedules/paged?page=&phone_id=&status=` | `{ schedules, total, page, page_size }` — filtering and slicing happen server-side |
| GET | `/schedules/{id}` | |
| POST | `/schedules` | |
| PUT | `/schedules/{id}` | |
| DELETE | `/schedules/{id}` | |
| POST | `/schedules/{id}/run` | sets `next_run = now`; the Scheduler fires on its next sweep. Asynchronous by design |
| GET | `/schedules/{id}/calls?page=` | `{ calls, total, page, page_size }` |
| GET | `/schedules/calls/{call_id}/events` | `{ events }` |

## Calls (live session)

| Method | Path | Notes |
|---|---|---|
| POST | `/calls/start` | `{ phone_id, contact_id, scenario_id, duration_seconds }` |
| GET | `/calls/active/{phone_id}/{contact_id}` | resume an existing session |
| GET | `/webhook-registrations/poll/{phone_id}/{contact_id}` | primary message poll |
| GET | `/calls/{call_id}/messages?since=` | fallback poll and backfill on resume |
| POST | `/calls/end` | `{ call_id, status }` |
| GET | `/calls/{call_id}` | |

**Route ordering matters.** `/calls/active/{phone_id}/{contact_id}` must be
declared before `/calls/{call_id}`, or FastAPI matches the literal `active` as
a `call_id`.

## Contact calls (scenario call history)

| Method | Path | Notes |
|---|---|---|
| GET | `/contact_calls/{contact_id}?page=&status=&page_size=` | `page` is 1-based; `page_size` falls back to `bot_config` |
| GET | `/contact_calls/{contact_id}/{call_id}/flow` | flow snapshot for one call |
| GET | `/contact_calls/{contact_id}/active` | live call — see [05-active-calls.md](05-active-calls.md) |
| GET | `/phones/{phone_id}/active_calls` | all live calls on a phone |

List response:

```json
{
  "calls": [ /* call rows, each with a nested `scenarios` object */ ],
  "total": 128,
  "total_pages": 7,
  "page_size": 20,
  "statuses": ["completed", "failed", "expired"]
}
```

`statuses` is the distinct set of statuses present for this contact; the UI
renders it as filter chips, so it must reflect the whole result set and not
just the current page.

Flow response:

```json
{
  "call":     { "started_at": "…", "priority": 2, "scenarios": { … } },
  "snapshot": { "config": { "canvas": [ … ], "interval": { "mins": 0, "secs": 8 } } },
  "leaves":   [ { "step_id": "…", "status": "sent" } ],
  "events":   [ { "event_type": "message_sent", "created_at": "…" } ]
}
```

`snapshot` may be either the config itself or `{ config: … }` — the UI handles
both (`snap.config || snap`).

## Executions

| Method | Path | Notes |
|---|---|---|
| GET | `/executions/` | the list, with `pending` per row |
| GET | `/executions/sources` | the user's phones + scenario counts |
| GET | `/executions/contacts?q=&limit=` | active-contact search |
| GET | `/executions/seek/{phone_number}` | which phones that contact is linked on |
| POST | `/executions/scenarios` | `{ phone_ids }` |
| GET | `/executions/scenario-templates/{id}` | the templates one scenario uses |
| POST | `/executions/` | create |
| POST | `/executions/{id}/run` | fire every target job |
| POST | `/executions/{id}/stop` | |
| DELETE | `/executions/{id}` | |

### `GET /executions/contacts`

`q` changes the search mode, which is why one endpoint serves three cases:

| `q` | Returns |
|---|---|
| empty | the contacts linked on the most phones first |
| digits | match by number |
| text | match by name |

Each row carries `number`, `contact_name`, `phones` (a count) and
`phone_numbers`, so the UI can show "linked on 4 phones" without a second call.

### `GET /executions/seek/{phone_number}`

The mapping the create call needs:

```json
{ "contact_name": "Dana",
  "phones": [ { "phone_id": "…", "contact_id": "…", "phone_number": "9725…",
                "phone_status": "active", "provider": "baileys" } ] }
```

**`contact_id` is per phone.** The same person is a separate contact row on each
phone, and this response is the only place that mapping is assembled — which is
why `targets` below carries both ids rather than just the phone.

### `POST /executions/`

```json
{ "name": "run_20261025_1130",
  "contact_phone_number": "972541234567",
  "source_scenario_id": "…",
  "template_prefix": "run_20261025_1130",
  "targets": [ { "phone_id": "…", "contact_id": "…" } ] }
```

Creating an execution **duplicates three things per target**: the scenario as
`{name} {scenario}`, each template it uses as `{prefix}_{template}`, and a
**manual** schedule as `{name} JOB`. Nothing runs until `POST /{id}/run`, which
fires every one of those jobs in parallel.

Constraints the UI enforces and the server should too:

| Field | Rule |
|---|---|
| `contact_phone_number` | `^972\d{8,10}$` |
| `template_prefix` | `^[a-z][a-z0-9_]{0,39}$` — a letter first, because it is prepended to a template name |
| `targets[].phone_id` | **Baileys only** — Cloud API templates are per business account, so there is nothing per-phone to copy |

`pending` on the list rows is the count of jobs the Scheduler has not picked up
yet. The screen polls every 5s while it is non-zero and disables ▶ until it
reaches 0 — see [screens/ExecutionsScreen.md](screens/ExecutionsScreen.md).

## Rented phones — `routers/RentDevice.py`

Physical phones with SIMs, rented for a fixed window. The rack is
[13-phone-farm.md](13-phone-farm.md); the admin side is
[orchestrator/06-devices.md](orchestrator/06-devices.md).

| Method | Path | Notes |
|---|---|---|
| GET | `/rent/phones?page=&search=` | available + mine, plus `rent_hours` |
| POST | `/rent/phones/{phone_id}` | rent — wipe, assign, re-seed |
| DELETE | `/rent/phones/{phone_id}` | end my rental |
| GET | `/rent/phones/{phone_id}/sms/threads?page=&search=` | SMS grouped by sender |
| GET | `/rent/phones/{phone_id}/sms/thread?target=&before_at=&before_id=` | one sender, newest first |

**Renting takes the same gate as provisioning** — admin **or** 2FA — because it
is a new phone for that user:

```python
if not (is_phone_admin(user) or is_2fa_verified(db, user["uid"])):
```

**The SMS endpoints check ownership in Python**, since every RPC runs as service
role:

```python
.eq("id", phone_id).eq("user_id", user["uid"]).not_.is_("sim_id", "null")
```

`sim_id is not null` is the half that makes it a *rented* phone, so these cannot
be pointed at an ordinary one.

The thread endpoint pages **backwards by keyset** — pass `before_at` +
`before_id` of the oldest row you already have. Two fields rather than one
because timestamps collide.

Errors map through one table (`REASONS`): `not_found` 404, `not_rentable`,
`not_available`, `not_rented` 409, `not_owner` 403, `bad_user` 400.
`not_available` is the one to show gently — it means somebody else rented it
while the page was open.

Expiry is a worker (`RENT_SWEEP_SEC`, default 60) running **in INTERNAL mode
only**; `/api/rent` does not exist in `client` mode.

## Templates

All under `/phones/{phone_id}/templates`:

| Method | Path | Notes |
|---|---|---|
| GET | `/?page=&status=&lang=&q=` | |
| GET | `/published` | |
| GET | `/{id}` | |
| POST | `/` | |
| PUT | `/{id}` | |
| POST | `/{id}/validate` | no body |
| PATCH | `/{id}/status` | `{ status, rejected_reason }` |
| POST | `/{id}/publish`, `/{id}/unpublish` | no body |
| POST | `/{id}/approve-publish` | **publishes an already-approved template**; 422 if status is anything else |
| POST | `/{id}/test-send` | `{ to, params }`; empty `params` uses the stored examples. Routed via Spine → HostAgent |
| DELETE | `/{id}` | |

Template placeholders are `{{1}}`, `{{2}}`, … The client mirrors
`template_manager.py` exactly (`paramsOf`, `paramMap`, `renderPreview` in
`src/api/templates.js`). If the server-side semantics change, both must move
together.

**Neither `publish` nor `approve-publish` approves anything.** Both require
`status == "approved"` and return 422 otherwise. Approval is written by
HostAgent's sync pass, out of band, roughly every two minutes — which also sets
`is_published`. The UI should therefore treat a freshly created template as
*pending and not yet actionable*, and expect it to become usable on its own.
See [09-templates-pipeline.md](09-templates-pipeline.md).

`POST /` always returns a draft (`pending`, unpublished) regardless of what the
provider ultimately says.

## Regex AI

Not under a phone — these are account-level AI helpers for the designer.

| Method | Path | Notes |
|---|---|---|
| POST | `/ai/regex/generate` | `{ request, samples? }` → `{ regex, conditions, whole_input, params, cached, ms, tests? }` |
| POST | `/ai/regex/test` | `{ regex, samples }` → `{ tests }`. No model call |
| GET | `/ai/regex/health` | `{ ok, status, models, max_model_len, cache_entries }` |

`request` is capped at 500 characters, `samples` at 20, `regex` at 2000.

**The error status is the diagnosis**: 400 is the caller, 422 is the model (and
carries its raw output in `detail.raw`), 502/503 is the AI service. The client
should surface 422 differently from 503 — one means "try rewording", the other
means "the service is down".

Full detail in [10-regex-ai.md](10-regex-ai.md).

## Errors

Non-2xx responses should return `{ "detail": "<string>" }`. `apiFetch` reads
`detail` when it is a string and otherwise falls back to `HTTP <status>`; the
thrown `Error` carries `.status` and `.body`. `401` is special-cased to
`"Session expired"`.

Endpoints that a UI component polls should return **200 with an empty-state
body**, not 404, so the polling loop does not run through its error branch on
every tick.
