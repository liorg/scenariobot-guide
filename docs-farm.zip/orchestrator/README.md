# PhoneOrchestrator

.NET 8 service, `BuildInfo.Version 1.0.9`, deployed as a **single-replica Swarm
service** on `orch.grossman.bot` (published port 8090). Two jobs that share
nothing but a process:

1. **Host supervision** — probe every `agent_hosts` machine, and when one stops
   answering, move its phones to a healthy host by flipping `phones.host_id`.
2. **Canary health checks** — drive a dedicated **Cloud API** prober that sends
   every active phone a coded template, and record whether the phone answered
   `ACK <code>` by itself.
3. **OTP sending** — take pending rows from `otp_requests` and send each one a
   `check_number` template through the same prober.
4. **Notification email** — mail `notifications` rows to their owners through
   Resend, as a per-user digest.

**The same image runs as two different services**, and `Orchestrator:Mode`
decides which background services start:

| Hosted service | `Mode=full` (`michal`) | `Mode=canary` (`botinbound`) |
|---|---|---|
| `OrchestratorLoop` — host supervision | **yes** | no |
| `NotificationMailer` — email | **yes** | no |
| `CanaryLoop` — health sweep | yes | yes |
| `OtpSender` — 2FA codes | no | **yes** |

`OtpSender` is on the canary instance because the prober is only reachable on
`whqueue-net`; everything else is there so two instances never drain or mail
the same thing. They share nothing but Supabase — see
[02-canary.md](02-canary.md).

| Doc | Covers |
|---|---|
| [01-host-supervision.md](01-host-supervision.md) | Probing, drain, placement gates |
| [02-canary.md](02-canary.md) | Canary v2 — CHECK ID / ACK, the prober, sweep outcomes |
| [03-spine-compat.md](03-spine-compat.md) | The v1 canary transport — **removed**, kept for context |
| [04-api-and-deploy.md](04-api-and-deploy.md) | Endpoints, auth, config, deployment |
| [05-notification-email.md](05-notification-email.md) | `NotificationMailer` — the digest mailer and its at-most-once claim |
| [06-devices.md](06-devices.md) | The devices page, the phone rack, rentals and `PairCodeProvisioner` |

`OtpSender` lives here too, but the pipeline it belongs to is documented with
the backend end of it: [../11-otp-2fa.md](../11-otp-2fa.md).

## This README is accurate

Unlike the Worker's and HostAgent's, this repository's `README.md` matches the
code, including its own "Known gaps" section. Treat it as current and read it
alongside these docs.

One gap it lists can now be closed. It says the HostAgent response shape is
unverified, and asks someone to check the real field names:

> If the endpoint returns 200 with a stale flag, `HeartbeatPayload.IsStale` /
> `Healthy` already cover it — check the real field names.

Checked against `HostController.GetHeartbeat`:

- **`isStale` exists** and is computed as `secondsSince > staleAfterSeconds`.
  `IsStale` binds correctly.
- **`healthy` does not exist.** `HeartbeatPayload.Healthy` is always null, so
  `payload?.Healthy == false` is always false. That half of the check is dead —
  harmless, because `IsStale` carries the signal.
- The other fields do not bind either. HostAgent returns **nested** objects —
  `cpu: { percent }`, `ram: { totalMb, usedMb, percent }`, `disk: { … }` —
  while `HeartbeatPayload` expects flat `CpuPercent`, `RamTotalMb` and so on.
  `PhoneCount` and `ContainerCount` are flat on both sides and do bind.

So the dashboard's CPU/RAM/disk enrichment from the probe is silently null. It
does not affect the drain decision, which is exactly the degradation the design
intended — but the display is not showing what it looks like it is showing.

## Two masters switches, both shipping off

| Switch | Default | Effect when false |
|---|---|---|
| `Orchestrator__AutoDrain` | `false` | probes, counts failures, shows verdicts — never writes to `phones` |
| `Orchestrator__CanaryEnabled` | `false` | `CanaryLoop` logs a warning and returns; no message reaches a customer phone |

Both are deliberate. Watch a real host go down, confirm the verdict was right,
then turn them on.
