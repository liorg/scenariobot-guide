# Devices and rentals

`devices.html` — the page that manages the **physical phone rack**, and the
endpoints behind it. The hardware side is
[../13-phone-farm.md](../13-phone-farm.md); this is the server's half.

Third page of the dashboard, beside Hosts and Canary:

```html
<a href="/">שרתים</a>
<a href="/devices.html" aria-current="page">מכשירים</a>
<a href="/canary.html">בדיקות</a>
```

Same conventions as the rest — no build step, no framework, one `.js` per page.

## Two views, one page

`devices.js` keeps a single `state` object and swaps `hidden` on two `<main>`
elements rather than routing:

| View | Shows |
|---|---|
| `devices` | one row per handset, paged |
| `sims` | the SIMs in one handset, with the actions |

A click on a device row opens its SIMs; **Back** returns. Everything reloads on
a 10-second tick, and the device list is reloaded alongside the SIM list so the
header stays current while you are inside one.

## The device row

| Column | From |
|---|---|
| serial | `device_id` — the ADB serial, the id everywhere |
| usb | `remove` → **usb disconnected**; `adb_state` other than `device` → that state; else **connected** |
| model · android | reported by the hub |
| docker | `update_from` — which hub it is on |
| verified / sims | how many SIMs are linked, out of how many |
| rented | how many are out with a customer |
| open verification | a warning chip when a pull is in flight |
| update | how long since `last_seen_at` |

That last column is the one to distrust: **there is no heartbeat**. `last_seen_at`
only moves when something changes, so an old value means "nothing has happened",
not "the hub is down". A hub that died stops reporting and every device it owns
stays `add` forever.

## The SIM row

| Column | Notes |
|---|---|
| sim | `slot + 1` — slot 0 is shown as SIM 1 |
| number | from the SIM, or from `devices.json` |
| whatsapp | WhatsApp / Business / **not installed** |
| verified | yes + when, or no |
| linked device | `linked_name` — what WhatsApp actually calls our link |
| customer | **Available** when the owner is the system user, otherwise the customer's email **and a live rental countdown** |
| last verification | the pull's status and age, with the error as a tooltip |

```js
const isOpen = (p) => p && ['pending', 'delete_old', 'ack'].includes(p.status);
```

A pull in one of those three states is still running, which is what disables
**Re-verify** on that row.

The countdown is redrawn every second **without refetching**:

```js
setInterval(() => {
  document.querySelectorAll('[data-left]').forEach(el => el.textContent = left(el.dataset.left));
}, 1000);
```

The deadline sits in a `data-left` attribute, so a ticking clock costs no
requests. Worth copying — the obvious version polls once a second.

## Re-verify

```js
const canVerify = s.phone_id && s.wa_type && !isOpen(s.pull) && !busy;
```

All four are necessary: a SIM with no `phones` row has nothing to pair against,
one with no WhatsApp has nothing to drive, and a pull already open would be
duplicated.

`POST /api/devices/sims/{simId}/reverify` creates the pull and returns; the hub
picks it up within five seconds and the row follows along through
`pending → delete_old / ack → success`. The full path is in
[../13-phone-farm.md](../13-phone-farm.md#re-verifying-a-phone-end-to-end).

A **409** is not an error here — it carries `{ok: false, reason}` from the RPC,
and the page translates it:

| `reason` | Means |
|---|---|
| `in_progress` | a verification is already running |
| `wa_not_installed` | no WhatsApp on that SIM |
| `not_rentable` | the SIM is not linked to a phone |
| `no_phone` | no `phones` row — the number is new |
| `already_system` | the phone is not with a customer |
| `not_rented` | no active rental |

```js
if (!res.ok && res.status !== 409) throw new Error(...)
return body;
```

Treating 409 as data rather than an exception is what lets the page say *why*
instead of "failed".

## Release from customer

The destructive one. It ends a rental **from the admin side** and wipes the
phone, and the page guards it by making the operator type the number:

```js
const typed = prompt(`… all contacts, scenarios, schedules, messages and SMS
of ${number} will be permanently deleted, and the phone returns to system.
There is no undo.\n\nTo continue — type the number (${number}):`);
if (digits(typed) !== digits(number)) { fail('number did not match'); return; }
```

A click is too cheap for an irreversible delete; typing the number means the
operator has read which phone it is. The comparison is on digits only, so
formatting does not matter.

> **Release from the Orchestrator does not re-seed the templates.** Only
> `RentDevice.py` does that, on the backend's own rent / end / expire paths. A
> phone released from this page comes back to the pool with its seed templates
> deleted, and the next renter gets a phone whose contact handshake cannot work
> until something re-seeds it. Worth fixing on this side, or routing the admin
> release through the same RPC.

## Rentals, on the backend side

`routers/RentDevice.py` owns what the customer sees
([../guide/20-rented-phones.md](../guide/20-rented-phones.md)).

| Endpoint | Does |
|---|---|
| `GET /rent/phones?page=&search=` | available + mine, with `rent_hours` |
| `POST /rent/phones/{id}` | rent: wipe → assign → re-seed |
| `DELETE /rent/phones/{id}` | end: wipe → back to the pool |
| `GET /rent/phones/{id}/sms/threads` | SMS grouped by sender |
| `GET /rent/phones/{id}/sms/thread` | one sender, keyset paging backwards |

**Renting is a new phone for the user**, so it takes the same gate as
provisioning one:

```python
if not (is_phone_admin(user) or is_2fa_verified(db, user["uid"])):
```

### The wipe, and what survives it

`_rent_wipe_phone` deletes contacts, calls, scenarios, schedules, messages, SMS,
`execution_links`, `scenario_runs`, `webhook_messages`, `ping_sender`,
`message_events`, `phone_provisioning_events`, notifications and `sender_log`.

Kept: the **seed templates**, `is_system` scenarios, and the `rent` history.

The keep-list is not hard-coded — it is derived:

```python
def _keep_templates() -> list[str]:
    from routers.template_manager import SEED_TEMPLATES
    return sorted({s["name"] for s in SEED_TEMPLATES})
```

So adding a seed template automatically protects it from the wipe, in all four
call sites. That is the right shape: the alternative is a literal list that
silently stops matching.

After every wipe, `_reseed` re-creates and re-publishes anything missing through
`phones._ensure_seed_templates` — belt and braces, since the wipe was supposed
to keep them.

### Expiry

A worker in the backend, not a cron:

```python
RENT_SWEEP_SEC = int(os.getenv("RENT_SWEEP_SEC", "60"))
expired = _rpc(db, "rpc_rent_expire", {"p_keep_templates": _keep_templates()})
```

`rpc_rent_expire` does the claiming with `skip locked`, so a second instance is
harmless. It runs **in INTERNAL mode only** — `/api/rent` does not exist in
`client` mode at all.

The UI does not depend on the sweep being punctual: the rent screen notices its
own countdown hitting zero and reloads five seconds later.

### Ownership is checked in Python, not in the RPC

```python
# every RPC runs as service role; ownership is checked here
def _require_my_rented_phone(db, user, phone_id):
    db.table("phones").select("id").eq("id", phone_id).eq("user_id", user["uid"])
      .not_.is_("sim_id", "null")
```

Both halves matter: `user_id` is the ownership check and `sim_id is not null`
is what makes it a *rented* phone, so the SMS endpoints cannot be pointed at an
ordinary phone.

## `PairCodeProvisioner`

Gets a fresh Baileys pairing code from the phone's own Manager, for the hub to
type into the handset. Reached the same way the scan loop reaches it —
`agent_hosts.ip_address` of `phones.host_id`.

```
use_pairing_code = false → POST /provision {usePairingCode: true}   (restarts the container)
then, until a code or the budget runs out:
  POST /pairing-code/refresh
    connected       → the unlink has not reached Baileys yet — wait 5s and retry
    pairing_ready   → the code
    pairing_pending → creds cleared + restart → poll GET /qrcode
```

The three statuses are three different waits, and conflating them is how this
flow breaks:

- **`connected`** means Baileys still thinks it is linked. The handset was
  unlinked seconds ago and the server has not noticed. Polling faster does not
  help, so this case waits 5 seconds rather than the usual 3.
- **`pairing_pending`** means the container is restarting with cleared
  credentials. The refresh endpoint will not answer again, so the loop **stops
  refreshing** and switches to polling `/qrcode`.

Everything is bounded by one budget passed in by the caller (~110 s), and the
failure is specific:

```csharp
return new(false, null, lastStatus == "connected" ? "still_connected" : "timeout", …);
```

`still_connected` says the old link never dropped — a real condition with a real
fix (unlink by hand) — while `timeout` says the code never came. One error code
for both would have hidden the common case.

Guards before any of that: the phone must exist, be `baileys`, have a
`host_id`, and that host must have an IP — `no_phone`, `not_baileys`,
`no_host`, `no_host_ip`.

## nginx

The hub and the browser come from the same public IP, so one `limit_req` zone
throttled both. At ~10 claims a minute the hub ate the budget and the dashboard
got 503s — and so did `paircode` and `finish`, which failed a verification.

```nginx
location /api/hub/ {          # Basic auth, no limit_req
    proxy_read_timeout 180s;  # paircode waits up to 110s; the default 60 is not enough
    proxy_send_timeout 180s;
}
location / {
    limit_req zone=orch burst=40 nodelay;
}
```

Both halves were needed: the separate location, **and** the raised timeout —
`paircode` legitimately holds a request open longer than nginx's default.

## Related

- [../13-phone-farm.md](../13-phone-farm.md) — the hub, the handsets, `phone.sh`
- [../guide/20-rented-phones.md](../guide/20-rented-phones.md) — the customer's view
- [04-api-and-deploy.md](04-api-and-deploy.md) — config and deployment
