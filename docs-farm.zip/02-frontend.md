# Frontend

React 18 + Vite. No CSS framework — styling is inline objects reading tokens
from `src/theme.js`, plus a `responsiveStyles` string of global CSS injected
once.

**Routing is hand-rolled, in `src/router.js`** — no router library. It is
`pushState` based, and the file says why hash routing was ruled out:

> Deliberately not hash — Supabase uses `#access_token`.

**The theme is light or dark**, resolved once when `theme.js` is imported.

## Layout

```
src/
  main.jsx              entry, mounts <App/> inside providers
  App.jsx               route rendering, top bar
  AuthContext.jsx       Supabase auth session
  LangContext.jsx       language + T() translator, sets <html dir>
  router.js             pushState routing — paths, parseRoute, useRoute, navigate
  theme.js              LIGHT/DARK tokens + global CSS string
  i18n.js               re-export shim  (infrastructure — never edit)
  i18n/{he,en,ru,ar}.js translation dictionaries
  lib/Supabase.js       Supabase browser client
  api/                  one module per resource, all through apiFetch
  screens/              full-page views
  components/           shared widgets and modals
  components/split/     the Split Designer editor
  utils/                componentTypes, cron, monacoSetup, touchDrag
  hooks/                useDenoCheck, useScenarioSave
```

## Screens

| Screen | Purpose |
|---|---|
| `LandingScreen` / `LoginScreen` / `ResetPasswordScreen` | Public + auth |
| `PhonesScreen`, `PhoneDetail` | Phone containers, QR pairing, status |
| `ContactsScreen` | Contacts per phone; entry point to a contact's calls |
| `ContactCallsScreen` | A contact's scenario calls — list, filter, paginate, flow |
| `CallsScreen` | WhatsApp chat view per contact (messages, not scenario calls) |
| `PlaybackChatScreen` | Replay of a recorded conversation |
| `ScenariosScreen` | Scenario CRUD |
| `SplitDesigner` | Visual scenario editor |
| `Schedulingscreen` | Cron schedules |
| `ExecutionsScreen` | Execution history |
| `SettingsScreen`, `PrivacyScreen` | Account, legal |

Naming is inconsistent (`Schedulingscreen`, and `PhoneDetail` exists in both
`screens/` and `components/`). Leave it alone unless you are refactoring
deliberately — imports are literal.

## API layer

`src/api/fetch.js` exports `apiFetch(endpoint, options)`. It:

- resolves the base URL from `VITE_API_URL`, defaulting to
  `https://vid.michal-solutions.com/api`
- pulls the Supabase access token from the current session and sends it as
  `Authorization: Bearer …`
- sets `Content-Type: application/json` unless the body is `FormData`
- throws on `401` with `"Session expired"`
- on any other non-2xx, throws an `Error` carrying `.status` and `.body`, with
  `message` taken from `detail` when it is a string

Every authenticated request goes through `apiFetch`. Never use bare `fetch`.

`src/api/index.js` is the barrel; `src/api.js` re-exports it so older imports
keep working. Note that `contactCallsApi` is **not** in the barrel — it is
imported directly from `../api/contactCalls.js`.

## Language and direction

`LangContext` stores the language in `localStorage` under `scenariobot_lang`,
falls back to the browser language, then to `he`. It writes `dir` and `lang`
onto `<html>` on every change. Supported: `he` (RTL), `en`, `ru`, `ar` (RTL).

Components get `const { lang, setLang, T } = useLang()` and call
`T("key", fallback)`.

Several screens — `ContactCallsScreen` among them — hardcode Hebrew strings and
`direction: "rtl"` rather than going through `T()`. That is the existing state,
not the target state; new strings in those files follow the local style so the
file stays coherent, and get migrated as a unit when the screen is localised.

## Split Designer

Three-column editor: `EXPECT | CANVAS | SEND`.

- `SplitDesigner.jsx` owns state; `components/split/` holds the pieces
- `cards/` — per-component-type editors (text, menu, buttons, input, code…)
- `interactive/` — arrow-driven dialogs (skip counter, time picker, wait-until)
- Undo/redo up to 50 operations, drag & drop with touch support via
  `utils/touchDrag.js`, Monaco (CDN loader) for code steps
- Live error detection is rendered by `ErrorsPanel.jsx`

## Environment variables

| Variable | Purpose |
|---|---|
| `VITE_SUPABASE_URL` | Supabase project URL |
| `VITE_SUPABASE_ANON_KEY` | Supabase anon key (public by design) |
| `VITE_API_URL` | UI backend base; falls back to the production URL |
| `VITE_APP_URL` | App's own origin, used for auth redirects |

`.env.local` is committed in the repo. Anything genuinely secret must not be
added to it — Vite inlines every `VITE_*` variable into the client bundle.

## Routing

`src/router.js` has no dependencies. Four exports carry the whole system:

| Export | Role |
|---|---|
| `paths` | **builders**, one per route — `paths.phone(id, tab)`, `paths.contactCall(p, c, call)` |
| `parseRoute(pathname)` | pathname → a flat route object (`{ section, phoneId, tab, contactId, … }`) |
| `useRoute()` | the hook every screen reads |
| `navigate(to, { replace })` / `closeTo(parent)` | navigation |

**Always build with `paths.*`, never by string concatenation.** The builders
`encodeURIComponent` every id, and they are the only place the shape of a URL
is written down.

`navigate` dispatches a custom `app:navigate` event alongside `pushState`,
because `pushState` fires no event of its own; `usePath` listens for that and
for `popstate`.

`closeTo(parent)` is the one to use when dismissing a modal or sub-screen:

```js
if (window.history.state?.prev === parent) window.history.back();
else navigate(parent, { replace: true });
```

It goes **back** when you arrived from the parent, so the history stack doesn't
grow on open/close cycles, and **replaces** when you arrived by deep link, so
back doesn't bounce you out of the app.

`KNOWN_SECTIONS` gates the top level — an unrecognised section redirects to
`/phones`. Unknown sub-segments fall back rather than erroring:
`PHONE_TABS.includes(seg[2]) ? seg[2] : "calls"`.

`/settings/:tab` works the same way: `paths.settings(tab)` builds it,
`route.settingsTab` reads it, and the Settings dialog treats it as the active
tab rather than holding tab state of its own. Two components depend on that
being in the URL — `TwoFactorBanner` deep-links to `paths.settings("2fa")`, and
hides itself when `route.settingsTab === "2fa"` so it does not sit above the
screen that resolves it.

## Gate components

`App.jsx` gates one **section** on 2FA, and it is the only one:

```js
const TWO_FA_SECTIONS = ["api", "rent"];
const sectionAllowed = (s) => tfa.verified || !TWO_FA_SECTIONS.includes(s);
```

Two things follow from that: those buttons are not rendered
(`{tfa.verified && <Btn …>API</Btn>}`), and `/api` redirects to `/phones` —
but only once the status has loaded:

```js
// only after status loaded, so a refresh doesn't bounce a verified user
if (user && !tfa.loading && !sectionAllowed(route.section)) navigate(paths.phones(), …)
```

Without the `!tfa.loading` guard, a verified user refreshing on `/api` would be
thrown to `/phones` before the status arrived — the redirect has to wait for
the answer, not assume one.

**Schedules are deliberately not in that list.** The comment explains why:

> Schedules stay visible: `spine_ensure_call` blocks the run itself
> (`TWO_FACTOR_REQUIRED`), so the screen is harmless.

`tfa.reload()` is called on `user?.id` change, because `useTwoFactor` ran once
at mount — without it, a sign-in would keep the previous user's status.

Three further components keep the UI honest about server-side gates. All
three are **UX only** — `routers/two_factor.py` and `routers/phone_admin.py`
enforce the real thing, and both files say so:

| Component | Reads | Renders |
|---|---|---|
| `TwoFactorBanner` | `useTwoFactor()` | an **unclosable** top banner until verified |
| `TwoFactorGate` | `useTwoFactor()` | greys out its children, with a link to the 2FA tab |
| `AddPhoneGate` | `useCanAddPhone()` → `GET /phones/can_add` | the same, plus the beta allowlist |

`useCanAddPhone` starts **locked** and stays locked until the server answers:

```js
useState({ canAdd: false, reason: LOCAL_ALLOWLIST.includes(email) ? "2fa" : "beta" })
```

> Until the server answers: 2FA is unknown → locked.

The local allowlist is a first-paint hint for the beta half only; the 2FA half
is never guessed. Failing closed is the right default here — the alternative
flashes an enabled button that then 403s.

A `2fa:changed` window event, fired after a successful verification, tells
`useCanAddPhone` to re-read, so the button un-greys without a reload. See
[11-otp-2fa.md](11-otp-2fa.md).

`sameId(a, b)` compares ids as strings, because a route segment is always a
string while the API may return a number.

The full URL table is in [guide/README.md](guide/README.md#every-screen-has-an-address).

### `/guide/:slug`

Not a screen. `App.jsx` redirects it to the published docs:

```js
if (route.guideSlug) { window.location.replace(chapterHref(route.guideSlug)); return; }
```

`/guide` with no slug opens the help dialog and replaces the URL with
`/phones`, so the dialog does not leave a dead entry in history.

## Theming

`theme.js` exports `LIGHT` and `DARK` token objects and resolves one of them
**at module load**, before anything else computes constants from it:

> The theme is applied here, at module load — before the other files compute
> constants from `T` (`STATUS_CONFIG`, `iSt` and so on). Switching = save +
> reload (the URL preserves the screen).

That is the constraint behind the design. Because `T` is a plain frozen-ish
object captured by other modules at import time, **switching cannot be
reactive** — `setThemeMode` writes `localStorage` and calls
`window.location.reload()`. The routing is what makes that acceptable: the
address bar holds the screen, so a reload returns to the same place.

Anything deriving values from `T` must do so at module scope or inside render;
caching a colour in a module-level constant computed before `theme.js` loads
would capture the wrong palette.

`document.documentElement` gets `dataset.theme` and `style.colorScheme`, which
is what makes browser-native scrollbars, selects and date pickers follow the
theme.

**`ThemeSwitcher`** sits in the top bar next to `LangSwitcher`; `darkMode` and
`lightMode` exist in all four i18n dictionaries.

Default is **light**, including when `localStorage` is unreadable.

