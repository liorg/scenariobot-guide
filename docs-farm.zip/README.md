# ScenarioBot / Grossman.Bot — Knowledge Base

A WhatsApp conversation-automation platform. Scenarios are authored visually,
compiled, and executed against real WhatsApp numbers; every execution is
recorded as a **call** with a step-by-step flow that can be replayed.

## Start here

| If you are… | Read |
|---|---|
| **a user of the product** | [guide](guide) — 17 chapters, each with its own click path |
| **new to the codebase** | [01-architecture.md](01-architecture.md), then the reading order below |
| **looking for one screen** | [screens](screens) — one doc per file in `src/screens/` |
| **debugging a live incident** | [whatsapp-single/04-operations.md](whatsapp-single/04-operations.md) |
| **working on Cloud API** | [cloudapi](cloudapi) — the newest part of the system |

## Contents

### Product

| Doc | Covers |
|---|---|
| [guide](guide) | **The user guide** — what the product does and how to drive it |

### The codebase

**The numbered files are a reading order** — 01 through 08, in that order, is
the tour. Everything else is a single feature documented on its own and read
when you need it.

| Doc | Covers |
|---|---|
| [01-architecture.md](01-architecture.md) | Services, data flow, invariants |
| [02-frontend.md](02-frontend.md) | React/Vite app structure, screens, state |
| [03-api-contract.md](03-api-contract.md) | Every endpoint the UI calls, with payloads |
| [04-scenario-model.md](04-scenario-model.md) | Scenario JSON, components, calls, leaves, events |
| [05-active-calls.md](05-active-calls.md) | The ACTIVE call feature — API + React |
| [06-conventions.md](06-conventions.md) | Hard rules for code, SQL, i18n |
| [07-deployment.md](07-deployment.md) | Build, deploy, environments |
| [08-user-guide.md](08-user-guide.md) | Chapter index for the user guide |
| [screens](screens) | One doc per file in `src/screens/` |

### Features

| Doc | Covers |
|---|---|
| [09-templates-pipeline.md](09-templates-pipeline.md) | Templates across all four services — seeding, sync, import, sending |
| [10-regex-ai.md](10-regex-ai.md) | Regex AI — free text → regex, the self-hosted Qwen3 service |
| [11-otp-2fa.md](11-otp-2fa.md) | Two-factor verification — the WhatsApp OTP pipeline and the gates it guards |
| [12-trusted-domains.md](12-trusted-domains.md) | Trusted domains — DNS/TLS verification and the script URL guard |
| [13-phone-farm.md](13-phone-farm.md) | The phone farm — `android_farm` / `phone-hub`, ADB-driven handsets, SMS and pair-code linking |

### The services

| Doc | Repository | What it is |
|---|---|---|
| [worker](worker) | `worker-scenario-runtime` | .NET 8 — the compiler and the execution engine |
| [spine](spine) | `ICR` | FastAPI — call lifecycle, queueing, Worker dispatch |
| [host-agent](host-agent) | `WhatsAppDockerManager` | .NET 8 — per-phone containers and the proxy |
| [orchestrator](orchestrator) | `PhoneOrchestrator` | .NET 8 — host supervision and canary health checks |
| [whatsapp-single](whatsapp-single) | `whatsapp-single` | Node + Python — the per-phone container itself |
| [cloudapi](cloudapi) | `whatsapp-cloudapi` + `whqueue` | Python — the Cloud API per-phone container and its webhook gateway |

## How a message actually flows

```
Scheduler ──▶ Spine ──▶ Worker ──▶ HostAgent ──▶ whatsapp-single ──▶ WhatsApp
             (FastAPI)  (.NET)     (.NET)        (Baileys)
                 ▲                                      │
                 └────────── webhook ───────────────────┘

Browser ──▶ UI backend (FastAPI) ──▶ Supabase
  (React)                       └──▶ HostAgent directly, for phone actions

PhoneOrchestrator supervises the hosts, and runs canary checks alongside.
```

A phone runs on one of **two providers**, and the Manager cannot tell which:

```
Baileys    container ──WebSocket──► WhatsApp
Cloud API  Meta ──► whqueue ──NATS──► container ──Graph──► Meta
```

Both expose the same HTTP API to the Manager. See [cloudapi](cloudapi).


Two invariants worth knowing before reading anything else:

- **Spine reacts, the Scheduler initiates.** Spine never starts a call on its
  own.
- **Spine is the only thing that talks to Workers.** The UI backend reaches
  HostAgent directly and never goes through Spine.

## Domains

| Domain | Serves |
|---|---|
| `grossman.bot` | React frontend (Vercel) |
| `api.grossman.bot` | UI backend (FastAPI) — OpenAPI at `/openapi.json` |
| `vid.michal-solutions.com/api` | UI backend (FastAPI) |
| `orch.grossman.bot` | PhoneOrchestrator |

## Reading order for a new contributor

0. **[guide](guide)** — what the thing actually does. Everything below is
   easier once the domain words mean something.
1. **[01-architecture.md](01-architecture.md)** — who talks to whom, and who is
   *not* allowed to talk to whom.
2. **[04-scenario-model.md](04-scenario-model.md)** — the domain objects.
   Everything else is plumbing around these.
3. **[03-api-contract.md](03-api-contract.md)** — the surface the frontend
   depends on.
4. **[06-conventions.md](06-conventions.md)** — read before writing any code or
   SQL.

## A note on the service READMEs

Three of the five service repositories have READMEs that have drifted from their
code. Each doc here opens by saying how far, so you know whether to trust what's
in the repo:

| Repository | Its README |
|---|---|
| `worker-scenario-runtime` | **stale** — Redis was removed entirely; `waitUntil` no longer skips |
| `WhatsAppDockerManager` | **stale** — there is no YARP, and half the config section is unused |
| `PhoneOrchestrator` | **accurate**, including its own "Known gaps" |
| `whatsapp-single` | **partly stale** — Redis is no longer in the container |
| `ICR` (Spine) | mostly accurate |

## Status

Written by reading the source of all six repositories. Sections marked
**[verify]** were inferred from frontend consumption rather than read from the
backend source or the live schema; confirm them before relying on them.
