# Screens

One document per file in `src/screens/`. Each covers what the screen is for,
its props, where its data comes from, and what will bite you.

| File | What it is |
|---|---|
| [LandingScreen](LandingScreen.md) | Public marketing page, dark themed, no API |
| [LoginScreen](LoginScreen.md) | Sign in / sign up / forgot, three modes in one form |
| [ResetPasswordScreen](ResetPasswordScreen.md) | New password after the emailed link |
| [PhonesScreen](PhonesScreen.md) | Home — phone cards plus the templates tab |
| [PhoneDetail](PhoneDetail.md) | Per-phone workspace, three tabs |
| [CallsScreen](CallsScreen.md) | WhatsApp chat view — 24-hour window, template sending; not scenario calls |
| [ContactsScreen](ContactsScreen.md) | Contact table, wizard, edit, delete |
| [ContactCallsScreen](ContactCallsScreen.md) | Scenario call history + the live call panel |
| [ScenariosScreen](ScenariosScreen.md) | Scenario list, create, open, play back |
| [SplitDesigner](SplitDesigner.md) | The visual editor |
| [PlaybackChatScreen](PlaybackChatScreen.md) | Replay, and live call execution |
| [Schedulingscreen](Schedulingscreen.md) | Cron schedules |
| [ApiExplorerScreen](ApiExplorerScreen.md) | Built-in Swagger-style API console |
| [ExecutionsScreen](ExecutionsScreen.md) | Parallel executions across phones |
| [SettingsScreen](SettingsScreen.md) | Account settings |
| [RentPhonesScreen](RentPhonesScreen.md) | Renting a physical phone with a SIM |
| [SmsScreen](SmsScreen.md) | SMS on a rented phone — threads and the keyset dialog |
| [PrivacyScreen](PrivacyScreen.md) | Privacy policy — legal text, do not edit |

`ExecutionsScreen.css` is the only stylesheet in the folder; every other screen
styles inline from `theme.js`.

## Things that are true across most of these screens

- **Every screen has a URL.** `src/router.js` is a hand-rolled `pushState`
  router; screens read `useRoute()` and navigate with `paths.*` builders rather
  than lifting state into `App.jsx`. Build URLs only through `paths.*`.
- **Light and dark.** `theme.js` resolves one palette at module load, so a
  switch reloads the page. Never cache a `T` value outside module scope.
- **Screens that replace themselves.** `ContactsScreen` returns
  `ContactCallsScreen` instead of its own markup when a contact's calls are
  opened. Nesting, not navigation.
- **Server-side filtering and paging** in `ContactCallsScreen`,
  `Schedulingscreen` and `ScenariosScreen`. Adding a client-side `.filter()`
  breaks the totals.
- **Polling without a visibility guard** in `CallsScreen` (5 s) and
  `PlaybackChatScreen` (3 s). `ActiveCallPanel` is the only one that pauses
  when the tab is hidden; the others should follow.
- **Mock data in production paths.** `APP_VERSION`, `STATUS_LABEL`,
  `DEMO_MESSAGES` and `MOCK_SCENARIOS` all come from `data/mockData.js`. The
  first two are real; the last two are genuinely mock and reach live screens.
- **Two `PhoneDetail.jsx` files.** `screens/` is live, `components/` is dead.
- **Hardcoded Hebrew** in `ContactCallsScreen`, `ContactsScreen` and parts of
  others, alongside `T()` everywhere else.
