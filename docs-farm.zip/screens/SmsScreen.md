# SmsScreen.jsx

The **SMS** tab in `PhoneDetail`, on a rented phone only. Text messages that
arrived on the SIM — not WhatsApp.

User-facing chapter: [../guide/21-sms.md](../guide/21-sms.md).

## It only exists on a rented phone

Two guards, in `PhoneDetail`:

```js
const activeTab = route.tab === "sms" && !phone.rented ? "calls" : (route.tab || "calls");
...(phone.rented ? [{ key: "sms", label: T("tabSms") }] : []),
```

The tab is not rendered, **and** the route falls back — so a bookmarked
`…/sms` on a phone whose rental ended lands on Calls instead of an empty screen.
`phone.rented` comes from the backend per request, not from a stored column
([../03-api-contract.md](../03-api-contract.md#three-fields-that-are-not-stored-on-the-row)).

## Two levels

| Component | Shows |
|---|---|
| `SmsScreen` | senders, paged and searchable, polled every 15 s |
| `SmsDialog` | one sender's messages, polled every 8 s |

Threads are grouped server-side (`rpc_sms_threads`), so the list is one request
regardless of how many messages exist.

## The dialog is the interesting part

It is a chat window built on **keyset paging backwards**, and three separate
concerns keep the scroll position sane.

**Newest at the bottom, oldest loaded on demand.** The API returns newest-first;
the screen reverses each page and merges:

```js
const merge = (older, newer) => {
  const seen = new Set(older.map(m => m.id));
  return [...older, ...newer.filter(m => !seen.has(m.id))];
};
```

Dedupe by id is what makes the 8-second poll safe — it re-fetches the newest
page every time, which overlaps what is already shown.

**`has_more` is taken from the first load only:**

```js
if (!first.current) { first.current = true; setHasMore(res.has_more); }
```

The polling call asks for the *newest* page, whose `has_more` describes the
wrong end of the conversation. Letting it through would turn off "load older"
after the first poll.

**Scroll position is restored by height difference, not by element:**

```js
if (anchor.current) {
  el.scrollTop += el.scrollHeight - anchor.current.prevHeight;
} else if (stick.current) {
  el.scrollTop = el.scrollHeight;
}
```

In `useLayoutEffect`, so it happens before paint — in `useEffect` the user sees
the jump. `anchor` is set just before loading older messages; `stick` records
whether the user was within 80px of the bottom, so incoming messages follow them
down only if they were already there.

**The no-scrollbar case is handled:**

```js
if (el && hasMore && !loadingOld && el.scrollHeight <= el.clientHeight + TOP_LOAD_PX) loadOlder();
```

A short first page leaves nothing to scroll, so the scroll handler never fires
and older messages are unreachable. This fills the window first.

## Gotchas

- **Inbound only.** There is no send path; the hub forwards what arrives.
- `target_phone` may be empty — those group under *Unknown sender*, keyed
  `"_"`.
- `unicodeBidi: "plaintext"` on message bodies: an SMS can be any language and
  the surrounding UI is RTL.
- Closing the dialog triggers a silent reload of the thread list, so the unread
  count and preview are current.
- Timestamps use `sort_at`, not `received_at` — the server picks which of the
  two timestamps orders the row, and the UI must not second-guess it.

## Related

- [RentPhonesScreen.md](RentPhonesScreen.md) — renting the phone in the first place
- [../13-phone-farm.md](../13-phone-farm.md) — how an SMS gets here
