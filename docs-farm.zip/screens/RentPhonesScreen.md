# RentPhonesScreen.jsx

The **Rented phones** tab — the pool of physical phones with SIMs. Opens at
`/rent`, beside the API console, and is gated on 2FA the same way
(`TWO_FA_SECTIONS = ["api", "rent"]` in `App.jsx`).

User-facing chapter: [../guide/20-rented-phones.md](../guide/20-rented-phones.md).

## Data

All through `rentApi` (`src/api/rent.js`) → `routers/RentDevice.py`:

| Call | Endpoint |
|---|---|
| `list({page, search})` | `GET /rent/phones` — plus `rent_hours` |
| `start(phoneId)` | `POST /rent/phones/{id}` |
| `end(phoneId)` | `DELETE /rent/phones/{id}` |

`onChanged` is called after every successful rent or end, so `App.jsx` can
reload the phone list — a rented phone appears in **Phones** immediately.

## Three clocks

This screen runs on time in three different ways, and they are deliberately not
the same mechanism:

| What | How | Why |
|---|---|---|
| the countdown | `useNow()` ticking locally | once a second, with **no requests** |
| other people's changes | `setInterval(load, 30_000)` silent | somebody else renting is not urgent |
| my rental expiring | a watcher on `msLeft() <= 0` | the server sweep decides, not the browser |

The third is the interesting one:

```js
if (p.mine && left <= 0 && !expiredRef.current.has(p.phone_id)) {
  expiredRef.current.add(p.phone_id);
  setTimeout(() => { load({ silent: true }); onChanged?.(); }, 5000);
}
```

`expiredRef` makes it fire **once per phone**, not on every tick after zero —
without it, a finished rental would reload the list every second.

The five-second delay is the server's: `rent_expiry_worker` sweeps on its own
interval, so reloading at exactly zero would show the phone still rented and
teach the user to distrust the clock.

`silent: true` on every background reload keeps the spinner for user-initiated
loads only.

## Rent is gated on four things

```js
disabled={busy || !!busyId || !online || !p.wa_type}
```

`!!busyId` is the global one: **any** row mid-action disables every Rent button,
because two rentals starting at once is the race the server would otherwise have
to resolve. `online` is `device_status === "add"` — the USB state reported by
the hub.

Ending is guarded by a `window.confirm` with the number interpolated, since it
deletes everything on the phone.

## Paging that survives a shrinking list

```js
if (res.page !== page) setPage(res.page);
```

The server clamps a past-the-end page and returns the one it actually used; the
screen adopts it. Someone else's rental can remove rows between two requests, so
page 4 can stop existing while you are on it.

Search is debounced 350 ms and resets to page 1.

## Small things worth keeping

- **`<bdi dir="ltr">` around every number and timer.** The UI runs RTL; without
  it a monospace `+9725…` renders with the sign in the wrong place.
- The countdown turns `theme.danger` under five minutes — the same threshold as
  the phone's own header in `PhoneDetail`.
- `Chip ok={...}` carries all four states (mine/available, WhatsApp installed or
  not, verified or not) through one component.
- Error and notice are separate pieces of state, and `doRent` clears both before
  starting — a stale success banner above a new failure would be worse than
  either alone.

## Related

- [SmsScreen.md](SmsScreen.md) — the tab a rented phone gains
- [../orchestrator/06-devices.md](../orchestrator/06-devices.md) — the admin side
- [../13-phone-farm.md](../13-phone-farm.md) — the hardware behind it
