# Phone farm — `android_farm` / `phone-hub`

Real Android handsets with real SIMs, on a rack, driven over **ADB**. The repo
is [liorg/android_farm](https://github.com/liorg/android_farm); the deployed
piece is a single Docker container, **`phone-hub`**, running on the NUC the
phones are plugged into.

It does three things, and they are the reason it exists:

| Job | What it means |
|---|---|
| **Device inventory** | which handsets are plugged in, which SIMs are in them, which WhatsApp apps are installed |
| **SMS** | text messages arriving on those SIMs, forwarded to the platform |
| **Pair-code linking** | linking Baileys to the handset **without touching the phone** |

The third is the point of the whole project. A phone with a real SIM is the
**primary** WhatsApp device; Baileys is a *linked* device, and linking normally
means a human scanning a QR code or typing an 8-character code into the handset.
This automates that.

## Why a physical phone

Redroid (Android in a container) was tried first and **WhatsApp blocks it
server-side**. A real handset registers without trouble, so the farm is real
hardware: a Galaxy A06 per number, charged over the same USB cable that carries
ADB.

That choice decides everything else. There is no API for "tap Linked devices" —
the hub drives the actual UI:

```
uiautomator dump   →  read the screen as XML
input tap <x,y>    →  press the button whose text matched
input text <code>  →  type the pairing code
```

`farm/phone.sh` holds those primitives (`tapui`, `waitfor`, `wake`) and the
WhatsApp flows built on them (`wa_link`, `wa_unlink`, `wa_rename`,
`wa_devices`).

## The shape of it

```
 handset (USB)                 NUC: phone-hub (docker, network_mode: host)        michal
┌──────────────┐  adb          ┌──────────────────────────────────────┐  HTTPS   ┌──────────────────┐
│ SmsAgent     │──reverse─────►│ :8080 /sms → outbox (SQLite)         │─ /api/hub/* ►│ PhoneOrchestrator│
│ WhatsApp     │◄─tap/text─────│ device_watcher  (adb track-devices)  │          │  ├► Supabase RPC │
│ WA Business  │               │ device_sender   → /device-update     │          │  └► Manager :5000│
└──────────────┘               │ sms_forwarder   → /sms               │          │     (pair code)  │
                               │ pull_loop       → /pulls/* + phone.sh│          └──────────────────┘
                               └──────────────────────────────────────┘
```

**The hub always calls out, never in.** No inbound port on the NUC, no tunnel,
no dynamic DNS — the rack can sit on any home network. Everything the server
wants done is expressed as work the hub **claims**.

That one decision is what makes the re-verify flow look the way it does, below.

## Three loops, three failure modes

`app.py` is four background tasks and a tiny HTTP API. The header says it
plainly: *three separate loops, each with its own failures*.

### 1. `device_watcher` — what is plugged in

One long-lived `adb track-devices`. ADB pushes a block on every change: four
hex digits of length, then `serial\tstate` per device.

```python
# the process dies (adb server restart) → back up after 3s
```

`state` is `device`, `unauthorized` (the phone never got "Always allow") or
`offline`.

On a new serial, before anything is reported, `configure` runs:

- removes the **legacy** agent package — two agents would each forward every SMS
- installs or updates **SmsAgent**, after turning off `verifier_verify_adb_installs`
  (Play Protect otherwise fails the install with no reason given)
- grants the SMS and phone permissions, adds the package to the **doze
  whitelist**, allows background running
- `adb reverse tcp:8080` and broadcasts the config to the agent

```python
# start the service without opening a screen (an open screen breaks the
# WhatsApp automation)
am start-foreground-service -n bot.grossman.smsagent/.AgentService
```

**`configure` runs on every connection, not just the first**, because the
reverse tunnel dies with the USB connection.

### 2. `device_sender` — telling the server

```python
dirty[serial] = update   # only the LAST update per serial
```

A coalescing map, flushed every two seconds. Success clears it; failure leaves
it for the next round, so a cloud outage **delays** an update rather than losing
one.

`UPDATE_FROM` names the hub. Left empty, the Orchestrator records the IP it
sees, which behind Swarm is `::ffff:10.0.0.2` — true and useless.

### 3. `sms_forwarder` — at-least-once, with backoff

SMS land in a **SQLite outbox** before anything else happens to them. The
forwarder drains it:

```python
delay = min(300, 5 * 2 ** attempts)    # 5s, 10s, 20s … capped at 5 min
```

Nothing is dropped on a failed send; the row stays `pending` with the error on
it. The far end dedupes by `msg_id`, which is what makes retrying safe.

The sender's own number is filled in here, from `devices.json`, if the agent
could not read it.

### 4. `pull_loop` — the work queue

Every five seconds, the hub asks the server what needs doing **for the serials
it can currently see**:

```python
serials = [s for s, d in devices.items() if d.get("state") == "device"]
```

It never claims work for a phone that is unplugged. `running_pulls` stops the
same job being started twice while it is in flight.

## Re-verifying a phone, end to end

This is the flow the whole project exists for. It starts from a button on the
Orchestrator's devices page
([orchestrator/06-devices.md](orchestrator/06-devices.md)):

```
UI  "Re-verify"   → POST /api/devices/sims/{simId}/reverify → rpc_pull_create → pending
hub (every 5s)    → POST /pulls/claim {serials}             → id, serial, slot, pkg, linked_name
hub               → wa_unlink <linked_name>        (only if there was one)
                  → POST /pulls/{id}/ack {unlinked}         → sim.verified = false
hub               → POST /pulls/{id}/paircode              → Orchestrator → PairCodeProvisioner
                       phones.host_id → agent_hosts.ip → Manager :5000
                       use_pairing_code=false → /provision {usePairingCode:true}
                       /pairing-code/refresh … → /qrcode, until a code (~110s)
hub               → wa_link <code> <pkg> [Grossman-<digits>]
                  → POST /pulls/{id}/finish {ok, linked_name} → sim.verified = true
```

Three details carry the design:

**Only our own device is unlinked.** `wa_unlink` takes the stored
`linked_name`, so a customer's own linked laptop is untouched. WhatsApp allows
four linked devices; unlinking blindly would break the customer's.

**`linked_name` is read back from what actually happened**, not from what was
requested:

```python
m = re.findall(r"linked(?: \(business\))? as: (.+)", out)
actual = m[-1].strip() if m else name
```

On **Business** the name is typed into the "Device name" screen. On plain
**WhatsApp** the list shows Baileys' browser string — `Google Chrome (Mac OS)`
unless `whatsapp-single` sets `browser: ['Grossman-<digits>', …]`. Storing the
requested name there would mean the *next* unlink cannot find the device, the
old link survives, and after four of those the phone cannot be linked at all.
Storing what was printed is what keeps the cycle repeatable.

**The pair code comes from the Manager, not from the hub.** `PairCodeProvisioner`
(in PhoneOrchestrator) asks the phone's own Baileys container for it, which is
why `phones.host_id` must be set — a number with no host fails with
`paircode: no_host`.

## `phone.sh`, and why `$S` and `$ADB` are variables

Every call is a fresh `bash` that sources the file and runs one function:

```python
env = {**os.environ, "S": serial, "ANDROID_SERIAL": serial,
       "ADB": " ".join(ADB), "PHONE_SH": PHONE_SH}
bash -c 'source "$PHONE_SH" >/dev/null && "$@"' phone-sh wa_link <CODE> <pkg> [name]
```

`S` is the serial from the pull, so **one script serves every phone on the
rack**; `ADB` is the container's adb. Hard-coding either (`S=R83L…`,
`ADB=scrcpy.adb`) would work on the bench and fail on the rack, so the file uses
`S=${S:-…}` and `ADB=${ADB:-scrcpy.adb}` and keeps working in both places.

`lock_for(serial)` allows **one UI action per phone at a time** — configure,
unlink and link cannot interleave on the same handset. Timeout is 150 seconds
and the last 4000 characters of output are kept; the last line becomes
`device_pull.error`.

> **The script now ships inside the image** (`/app/farm/phone.sh`, built from
> the commit in `SRC_SHA`), replacing the old `../farm:/app/farm:ro` mount. The
> repo's README still documents the mount in its "how phone.sh runs" section —
> that part is stale.

## What the handset has to be

These are requirements, not recommendations — each one breaks the automation:

| Requirement | Why |
|---|---|
| **No lock, or swipe only** | `wm dismiss-keyguard` does not get past a PIN, and the taps never reach WhatsApp |
| **English UI, in WhatsApp too** | `tapui` matches on-screen text — `Linked devices`, `Link a device`, `Save` |
| **Auto Blocker off** (Samsung) | it blocks USB commands and installs outright |
| **USB debugging, "Always allow"** | plus *Disable adb authorization timeout*, or the approval lapses after 7 days |
| **No other linked devices** | four is the limit, and `wa_unlink` only removes ours |
| **A data cable** | a charge-only cable shows nothing in `adb devices` |

`wake` turns the screen on before each flow and takes a dark screen in its
stride; the one thing it cannot do is unlock a PIN.

## `devices.json` — filling in what Android won't say

On Samsung, `content://telephony/siminfo` returns no number, and with two SIMs
and two WhatsApp apps the hub cannot tell which app belongs to which SIM. So
both are stated by hand:

```json
{"R83L6113LSF": {"sims": {
  "0": {"phone_number": "+972504477197", "wa_type": "whatsapp"},
  "1": {"phone_number": "+972508375877", "wa_type": "business"}
}}}
```

Then `curl -X POST localhost:8080/devices/<serial>/configure`.

A key that is **not sent** keeps its stored value, while `wa_type: null` means
*not installed* — so a partial update cannot silently erase what is known.

## The contract with the Orchestrator

`POST /api/hub/*`, Basic auth as the `hub` user:

| Endpoint | Body | Answer |
|---|---|---|
| `/device-update` | `device_id, status, adb_state, update_from?, model, android, sims[]` | the `rpc_device_update` result |
| `/sms` | `msg_id, device_id, sim_slot, source_phone?, from, body, sent_at, received_at` | `{ok, inserted, sms_id, phone_id}` |
| `/pulls/claim` | `serials[], update_from?` | `{pulls: [{id, serial, slot, phone_number, wa_type, pkg, linked_name}]}` |
| `/pulls/{id}/ack` | `unlinked, unlinked_name?, result?` | `{ok, status, expires_at, unlinked_name}` |
| `/pulls/{id}/paircode` | — | `{code, pkg, expires_at, name}` · 502 `{reason}` |
| `/pulls/{id}/finish` | `ok, linked_name?, error?, result?` | `{ok, status, linked_name}` |

A SIM whose number has no `phones` row gets one created as a **system** phone
(`inactive`, `stopped`, `baileys`) — which is what later makes it rentable
([guide/20-rented-phones.md](guide/20-rented-phones.md)). A SIM moved to another
handset releases its old link.

## Deployment

```bash
# NUC: ~/projects/github/android_farm/phone-hub
docker compose up -d phone-hub                  # .env or compose changed
./build.sh && docker compose up -d phone-hub    # app.py changed
```

`.env` needs `HUB_URL`, `HUB_USER`, `HUB_PASSWORD`, `UPDATE_FROM`,
`PULL_INTERVAL_SEC`. Build-only secrets — `GITHUB_TOKEN`, `SMSAGENT_KS_B64`,
`SMSAGENT_KS_PASS` — are passed as compose secrets and **not kept in the
image**.

Three volumes matter:

| Mount | Why |
|---|---|
| `/dev/bus/usb` | with `privileged: true`, so phones plugged in later are seen |
| `./data` | the outbox and `devices.json` |
| `./adbkey` | **the host key the phones approved.** Copy this folder to move the rack to another machine; without it every phone has to be approved again |

`network_mode: host` is required: `adb reverse` points the handset at
`127.0.0.1:8080` *of the NUC*, which must be the hub.

## Known gaps

- **No heartbeat.** Status is only sent on change, so if the hub itself dies,
  `device.status` stays `add` and `last_seen_at` stops moving. A device that has
  gone quiet is indistinguishable from one that is fine.
- **A new number needs a manual provision** in the Manager, to get a `host_id`;
  until then re-verify fails with `no_host`.
- **`adb` version clashes.** `network_mode: host` means the container's adb
  server owns port 5037. A different `scrcpy.adb` on the NUC will kill and
  restart it, cutting `track-devices` mid-flow. Compare versions before running
  both.
- SMS → Manager → Worker is still a TODO in `HubController.Sms`; the messages
  reach the database but no scenario can react to one yet.

## Related

- [orchestrator/06-devices.md](orchestrator/06-devices.md) — the devices page and the hub endpoints
- [guide/20-rented-phones.md](guide/20-rented-phones.md) — what a customer sees
- [guide/21-sms.md](guide/21-sms.md) — the SMS tab
